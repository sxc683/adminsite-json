
import NmHttp from "http";
import NmUrl from "url";
import NmQuerystring from "querystring";
import NmFs from "fs";
import NmPath from "path";
import DataParse from './commom/DataParse.js';

const __dirname = NmPath.dirname(NmUrl.fileURLToPath(import.meta.url));

import routerIndex from './route/Index.js'
const routers = routerIndex.getAdminRouters();

const host = {
    ip: '127.0.0.1',
    port: 3000
}

const server = NmHttp.createServer((req, res) => {
    // 处理输入请求参数
    // 解析地址。req.url=/，是相对路径，所以要加 baseUrl 参数
    let urlObj = new NmUrl.URL(req.url, 'http://' + host.ip);
    let urlPathName = urlObj.pathname; // 路由路径（?前面的相对路径）
    // 获取 URL 参数对象
    let urlParams = urlObj.searchParams;
    // 获取表单提交的内容
    let reqBody = '';
    req.on('data', function (data) {
        reqBody += data;
    })
    // 用于数据接收完成后再获取
    req.on('end', async function () {
        let formParams = DataParse.StringToJson(reqBody);
        // 获取请求类型(GET,POST,DELETE...)
        let reqMethod = req.method;
        // 伪装请求类型处理，可以在表单中带 _method 文本域，值可为 GET,POST,PUT,DELETE。
        if (urlParams.has('_method')) {
            reqMethod = urlParams.get('_method');
        }
        if (typeof (formParams['_method']) != 'undefined') {
            reqMethod = formParams['_method'];
        }

        // 静态目录处理
        if (urlPathName.lastIndexOf('.js') > 0) {
            res.statusCode = 200;
            res.end(NmFs.readFileSync(NmPath.join(__dirname, urlPathName)))
            return;
        }
        // 返回内容
        let content = {
            msg: '路由错误',
            code: 404
        };
        // 简易路由处理
        if (routers.hasRoute(reqMethod, urlPathName)) {
            content = await routers.callback(reqMethod, urlPathName, urlParams, formParams);
        }
        // 处理输出
        if (content.status == 0 && content.code == 404) {
            res.writeHead(404);
            res.end(JSON.stringify(content));
            return;
        }
        res.statusCode = 200;
        // 自动判断返回值的类型，调用对应的返回处理方式
        switch (typeof (content)) {
            case 'object':
                content = JSON.stringify(content);
                res.setHeader('Content-Type', 'application/json');
                res.setHeader('Content-Length', Buffer.byteLength(content))
                res.end(content)
                break;
            default:
                if (content.indexOf('<') > -1 && content.indexOf('>') > -1) {
                    res.setHeader('Content-Type', 'text/html;charset=utf-8');
                } else {
                    res.setHeader('Content-Type', 'text/plain');
                }
                res.setHeader('Content-Length', Buffer.byteLength(content))
                res.end(content);
                break;
        }
    })
})
// 开始监听
server.listen(host.port, host.ip, () => {
    console.log(`服务器运行在 http://${host.ip}:${host.port}`);
})