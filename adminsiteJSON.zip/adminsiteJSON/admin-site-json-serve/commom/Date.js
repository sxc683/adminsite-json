import SillyDatetime from 'silly-datetime';

function getNowDate(fmt = 'YYYY-MM-DD HH:mm:ss') {
    const time = SillyDatetime.format(new Date(), fmt);
    return time;
}

export default { getNowDate }