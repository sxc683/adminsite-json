import crypto from 'crypto'

// 路由类
class Router {
    routes = {};
    getKey(method, url) {
        return crypto.createHash('md5').update(method + url).digest('hex').substring(8, 16);
    }
    hasRoute(method = '', url = '') {
        return typeof (this.routes[this.getKey(method.toUpperCase(), url)]) != 'undefined';
    }
   async callback(method = '', url = '', urlParams = null, formParams = null) {
        let cb = this.routes[this.getKey(method.toUpperCase(), url)].cb;
        if (typeof (cb) == 'function') {
            return await cb(urlParams, formParams)
        }
        // api/LoginController.login
        if (typeof (cb) == 'string') {
            let paths = cb.split('.', 2);
            const Controller = await import('../' + paths[0] + '.js')
            return new Controller.default()[paths[1]]();
        }
    }
    addRoute(method = '', url = '', cb = null) {
        method = method.toUpperCase();
        this.routes[this.getKey(method, url)] = {
            method: method,
            url: url,
            cb: cb
        };
    }
    get(url, cb) {
        this.addRoute('GET', url, cb);
    }
    post(url, cb) {
        this.addRoute('POST', url, cb);
    }
    put(url, cb) {
        this.addRoute('PUT', url, cb);
    }
    delete(url, cb) {
        this.addRoute('DELETE', url, cb);
    }
    header(url, cb) {
        this.addRoute('HEADER', url, cb);
    }
}

export default { Router }