import Router from './Route.class.js'
import Controller from '../controller/Index.js'
import Api from '../api/Index.js'

// 获取路由配置
function getAdminRouters() {
    let route = new Router.Router();
    Controller.controllerList.forEach(item => {
        route.get(item[0], item[1])
    })
    Api.forEach(item => {
        item[1] = '/api' + item[1]
        if (item[0] == 'get') {
            route.get(item[1], item[2])
        }
        if (item[0] == 'post') {
            route.post(item[1], item[2])
        }
        if (item[0] == 'put') {
            route.put(item[1], item[2])
        }
        if (item[0] == 'delete') {
            route.delete(item[1], item[2])
        }
    })

    return route;
}

export default { getAdminRouters };