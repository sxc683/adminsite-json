import NmFs from 'fs'
import NmPath from 'path'
import { fileURLToPath } from 'url'
const __dirname = NmPath.dirname(fileURLToPath(import.meta.url));

class MainController {
    Main() {
        let html = NmFs.readFileSync(NmPath.join(__dirname, '../view/main/main.html'));
        return html.toString();
    }
}

export default MainController;