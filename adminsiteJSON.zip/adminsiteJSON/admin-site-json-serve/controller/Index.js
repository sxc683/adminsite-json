export default {
    controllerList: [
        ['/', 'controller/MainController.Main']
    ]
};