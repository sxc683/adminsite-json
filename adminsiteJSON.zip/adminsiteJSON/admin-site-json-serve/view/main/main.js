function getTime() {
    setInterval(() => {
        var myDate = new Date();
        document.getElementById('maintext').innerText = '服务启动：'
            + myDate.getFullYear() + '-' + (myDate.getMonth() + 1) + '-' + myDate.getDate() + ' ' +
            myDate.getHours() + ":" + myDate.getMinutes() + ":" + myDate.getSeconds()
    }, 1000)
}

