import DataBaseConnect from '../commom/DataBaseConnect.js';

const getViewsType = [
    'get',
    '/getViewsType',
    async function (urlParams) {
        const db = DataBaseConnect.getJsonDB('../db/BasisDB.json')
        await db.read()
        return {
            msg: 'getViewsType',
            data: db.data.ViewsType,
            code: 0
        }
    },
]

const getRoutesType = [
    'get',
    '/getRoutesType',
    async function (urlParams) {
        const db = DataBaseConnect.getJsonDB('../db/BasisDB.json')
        await db.read()
        return {
            msg: 'getRoutesType',
            data: db.data.RoutesType,
            code: 0
        }
    },
]

export default [
    getViewsType,
    getRoutesType
]