import DataBaseConnect from '../commom/DataBaseConnect.js';
import DataParse from '../commom/DataParse.js';
import uuid from 'node-uuid'
import Date from '../commom/Date.js'

const getAllCaxRoutesBytree = [
    'post',
    '/getAllCaxRoutesBytree',
    async function (urlParams, formParams) {
        const db = DataBaseConnect.getJsonDB('../db/CaxRoutesDB.json')
        let name = formParams && formParams.name != null && formParams.name != undefined ? String(formParams.name) : "";
        let type = formParams && formParams.type != null && formParams.type != undefined ? String(formParams.type) : "";
        await db.read()
        const searchResData = db.data.filter(item => {
            return ((String(item.name)).indexOf(name) >= 0 && (String(item.type)).indexOf(type) >= 0) || item.parentId == null
        })
        const resdata = DataParse.ArraytoTree(searchResData)
        return {
            msg: 'getAllCaxRoutesBytree',
            data: resdata,
            code: 0
        }
    },
]

const getAllCaxRoutesByList = [
    'post',
    '/getAllCaxRoutesByList',
    async function (urlParams, formParams) {
        const db = DataBaseConnect.getJsonDB('../db/CaxRoutesDB.json')
        await db.read()
        let name = formParams && formParams.name != null && formParams.name != undefined ? String(formParams.name) : "";
        let type = formParams && formParams.type != null && formParams.type != undefined ? String(formParams.type) : "";
        await db.read()
        const searchResData = db.data.filter(item => {
            return (String(item.name)).indexOf(name) >= 0 && (String(item.type)).indexOf(type) >= 0
        })
        return {
            msg: 'getAllCaxRoutesByList',
            data: searchResData,
            code: 0
        }
    },
]

const addCaxRoute = [
    'post',
    '/addCaxRoute',
    async function (urlParams, formParams) {
        const db = DataBaseConnect.getJsonDB('../db/CaxRoutesDB.json')
        await db.read()
        if (Array.isArray(db.data)) {
            const myDate = Date.getNowDate();
            formParams['creationTime'] = myDate
            formParams['id'] = uuid.v4()
            db.data.push(formParams)
            await db.write()
        }
        return {
            msg: 'addCaxRoute',
            data: db.data,
            code: 0
        }
    },
]

const removeCaxRoute = [
    'post',
    '/removeCaxRoute',
    async function (urlParams, formParams) {
        const db = DataBaseConnect.getJsonDB('../db/CaxRoutesDB.json')
        await db.read()
        if (formParams && formParams.id && Array.isArray(db.data)) {
            db.data = db.data.filter(item => {
                return item.id != formParams.id
            })
            await db.write()
        }
        return {
            msg: 'removeCaxRoute',
            data: db.data,
            code: 0
        }
    },
]

const updataCaxRoute = [
    'post',
    '/updataCaxRoute',
    async function (urlParams, formParams) {
        const db = DataBaseConnect.getJsonDB('../db/CaxRoutesDB.json')
        await db.read()
        if (formParams && formParams.id && Array.isArray(db.data)) {
            db.data = db.data.map(item => {
                if (item.id == formParams.id) {
                    const myDate = Date.getNowDate();
                    formParams['creationTime'] = myDate
                    item = formParams
                }
                return item;
            })
            await db.write()
        }
        return {
            msg: 'updataCaxRoute',
            code: 0
        }
    },
]

const findCaxRouteByID = [
    'get',
    '/findCaxRouteByID',
    async function (urlParams) {
        let id = urlParams.has('id') ? urlParams.get('id') : "";
        const db = DataBaseConnect.getJsonDB('../db/CaxRoutesDB.json')
        await db.read()
        let res = {}
        if (id && Array.isArray(db.data)) {
            res = db.data.filter(item => {
                return item.id == id
            })
            res = res.length > 0 ? res[0] : {}
        }
        return {
            msg: 'findCaxRouteByID',
            data: res,
            code: 0
        }
    },
]

export default [
    getAllCaxRoutesBytree,
    getAllCaxRoutesByList,
    addCaxRoute,
    removeCaxRoute,
    updataCaxRoute,
    findCaxRouteByID
]