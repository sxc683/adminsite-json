import Demo from './Demo.js';
import Basis from './Basis.js';
import CaxRoutes from './CaxRoutes.js';
import CaxViews from './CaxViews.js';

export default [...Demo, ...CaxRoutes, ...Basis, , ...CaxViews
];