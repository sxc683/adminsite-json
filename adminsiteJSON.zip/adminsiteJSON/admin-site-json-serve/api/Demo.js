const getDemo = [
    'get',
    '/getDemo',
    function (urlParams) {
        let id = urlParams.has('id') ? parseInt(urlParams.get('id')) : 0;
        return {
            msg: 'getDemo',
            data: 'id_' + id,
            code: 0
        }
    },
]

const postDemo = [
    'post',
    '/postDemo',
    function (urlParams, formParams) {
        return {
            msg: 'postDemo',
            data: formParams,
            code: 0
        }
    },
]

export default [
    getDemo,
    postDemo,
]