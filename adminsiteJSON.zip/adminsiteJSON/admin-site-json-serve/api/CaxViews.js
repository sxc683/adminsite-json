import DataBaseConnect from '../commom/DataBaseConnect.js';
import uuid from 'node-uuid'
import Date from '../commom/Date.js'

const getAllCaxViews = [
    'get',
    '/getAllCaxViews',
    async function (urlParams) {
        const db = DataBaseConnect.getJsonDB('../db/CaxViewsDB.json')
        await db.read()
        return {
            msg: 'getAllCaxViews',
            data: db.data,
            code: 0
        }
    },
]

const searchPageCaxViews = [
    'post',
    '/searchPageCaxViews',
    async function (urlParams, formParams) {
        const db = DataBaseConnect.getJsonDB('../db/CaxViewsDB.json')
        await db.read()
        let pageSize = formParams && formParams.pageSize ? formParams.pageSize : 10;
        let currentPage = formParams && formParams.currentPage ? formParams.currentPage : 10;
        let name = formParams && formParams.name !=null && formParams.name !=undefined  ? String(formParams.name) : "";
        let type = formParams && formParams.type !=null && formParams.type !=undefined ? String(formParams.type) : "";
        const searchResData = db.data.filter(item => {
            return (String(item.name)).indexOf(name) >= 0 && (String(item.type)).indexOf(type) >= 0
        })
        const res = {
            rows: searchResData.slice(pageSize * (currentPage - 1), pageSize * (currentPage)),
            total: searchResData.length,
            pageSize: pageSize,
            currentPage: currentPage,
            pageCount: Math.ceil(searchResData.length / pageSize)
        }
        return {
            msg: 'searchPageCaxViews',
            data: res,
            code: 0
        }
    },
]

const addCaxView = [
    'post',
    '/addCaxView',
    async function (urlParams, formParams) {
        const db = DataBaseConnect.getJsonDB('../db/CaxViewsDB.json')
        await db.read()
        if (Array.isArray(db.data)) {
            const myDate = Date.getNowDate();
            formParams['creationTime'] = myDate
            formParams['id'] = uuid.v4()
            db.data.push(formParams)
            await db.write()
        }
        return {
            msg: 'addCaxView',
            code: 0
        }
    },
]

const removeCaxView = [
    'post',
    '/removeCaxView',
    async function (urlParams, formParams) {
        const db = DataBaseConnect.getJsonDB('../db/CaxViewsDB.json')
        await db.read()
        if (formParams && formParams.id && Array.isArray(db.data)) {
            db.data = db.data.filter(item => {
                return item.id != formParams.id
            })
            await db.write()
        }
        return {
            msg: 'removeCaxView',
            code: 0
        }
    },
]

const updataCaxView = [
    'post',
    '/updataCaxView',
    async function (urlParams, formParams) {
        const db = DataBaseConnect.getJsonDB('../db/CaxViewsDB.json')
        await db.read()
        if (formParams && formParams.id && Array.isArray(db.data)) {
            db.data = db.data.map(item => {
                if (item.id == formParams.id) {
                    const myDate = Date.getNowDate();
                    formParams['creationTime'] = myDate
                    item = formParams
                }
                return item;
            })
            await db.write()
        }
        return {
            msg: 'updataCaxView',
            code: 0
        }
    },
]

const findCaxViewByID = [
    'get',
    '/findCaxViewByID',
    async function (urlParams) {
        let id = urlParams.has('id') ? urlParams.get('id') : "";
        const db = DataBaseConnect.getJsonDB('../db/CaxViewsDB.json')
        await db.read()
        let res = {}
        if (id && Array.isArray(db.data)) {
            res = db.data.filter(item => {
                return item.id == id
            })
            res = res.length > 0 ? res[0] : {}
        }
        return {
            msg: 'findCaxViewByID',
            data: res,
            code: 0
        }
    },
]

export default [
    getAllCaxViews,
    searchPageCaxViews,
    addCaxView,
    removeCaxView,
    updataCaxView,
    findCaxViewByID
]