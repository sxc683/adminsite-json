<template>
  <router-view />
</template>

<style lang="scss">
body {
  height: 100vh;
  width: 100vw;
  margin: 0px !important;
}
</style>
