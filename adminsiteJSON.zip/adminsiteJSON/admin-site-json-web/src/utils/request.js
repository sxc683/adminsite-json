import axios from "axios";

axios.defaults.timeout = 30000;
axios.defaults.withCredentials = true;

axios.interceptors.request.use(
  (config) => {
    return config;
  },
  (err) => {
    return Promise.reject(err);
  }
);

axios.interceptors.response.use(
  function (response) {
    return response.data ? response.data : {};
  },
  function (error) {
    return Promise.reject(error);
  }
);

const METHOD = {
  GET: "get",
  POST: "post",
  PUT: "put",
  DELETE: "delete",
};

async function request(url, method, params) {
  switch (method) {
    case METHOD.GET:
      return axios.get(url, {
        params,
      });
    case METHOD.POST:
      return axios.post(url, params);
    case METHOD.PUT:
      return axios.put(url, params);
    case METHOD.DELETE:
      return axios.delete(url, params);
    default:
      return axios.get(url, {
        params,
      });
  }
}

export { request };
