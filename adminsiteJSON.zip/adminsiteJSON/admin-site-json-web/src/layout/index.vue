<template>
  <div class="common-layout">
    <el-container>
      <el-aside class="layoutAside">
        <navbar></navbar>
      </el-aside>
      <el-container>
        <el-header class="layoutHeader">BackendWeb</el-header>
        <el-main class="layoutMain">
          <router-view />
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script>
import Navbar from "./components/navbar.vue";

export default {
  name: "index-layout",
  components: {
    Navbar,
  },
};
</script>

<style lang="scss" scoped>
@import "@/styles/layout-defult.scss";

.common-layout {
  height: 100vh;
  width: 100vw;
}

.layoutHeader {
  height: calc($headerHeight - 1px);
  width: calc(100vw - $sideBarWidth);
  padding: 0 20px;
  background: $headerBackground;
  line-height: $headerHeight - 1px;
  font-size: $headerHeight - 40px;
  border-bottom: solid 1px $headerBorderBottomColor !important;
}

.layoutAside {
  width: $sideBarWidth - 1px;
  height: 100vh;
  border-right: solid 1px $sideBarBorderRightColor !important;
}

.layoutMain {
  padding: 10px !important;
  width: calc(100vw - $sideBarWidth);
  height: calc(100vh - $headerHeight);
}
</style>
