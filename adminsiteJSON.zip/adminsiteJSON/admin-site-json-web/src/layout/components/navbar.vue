<template>
  <el-menu default-active="2" class="main-menu">
    <el-sub-menu index="1">
      <template #title>
        <span>Basic Service Management</span>
      </template>
      <el-menu-item index="1-1" @click="menuSelect('CaxRoutesListPage')">
        <span>Cax Routes</span></el-menu-item
      >
      <el-menu-item index="1-2" @click="menuSelect('CaxViewsListPage')">
        <span>Cax Views</span></el-menu-item
      >
    </el-sub-menu>
  </el-menu>
</template>

<script>
export default {
  name: "navbar-index",
  data() {
    return {};
  },
  methods: {
    menuSelect(url) {
      this.$router.push({
        name: url,
      });
    },
  },
};
</script>

<style lang="scss" scoped>
@import "@/styles/layout-defult.scss";

.main-menu {
  border-right: none;
  width: $sideBarWidth - 2px;
}
</style>
