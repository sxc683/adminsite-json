<template>
  <main-template>
    <template v-slot:header>欢迎使用</template>
  </main-template>
</template>

<script>
import MainTemplate from "@/components/main-template.vue";

export default {
  name: "main-index",
  components: {
    MainTemplate,
  },
};
</script>
