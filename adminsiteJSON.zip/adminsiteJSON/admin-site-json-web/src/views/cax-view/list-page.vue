<template>
  <main-template>
    <template v-slot:header
      ><span>Routes</span>
      <el-button @click.prevent="addRow" style="float: right"
        >Add</el-button
      ></template
    >
    <template v-slot:search>
      <el-form :inline="true" :model="form" class="demo-form-inline">
        <el-form-item label="name">
          <el-input v-model="form.name" clearable></el-input>
        </el-form-item>
        <el-form-item label="type">
          <el-select v-model="form.type" clearable>
            <el-option
              v-for="(selectDataItem, indexItem) in selectData"
              :key="indexItem"
              :label="selectDataItem.label"
              :value="selectDataItem.value"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="search">Query</el-button>
        </el-form-item>
      </el-form>
    </template>
    <template v-slot:main>
      <el-table :data="tableData" style="width: 100%">
        <el-table-column prop="id" label="id" width="450" />
        <el-table-column prop="name" label="name" width="150" />
        <el-table-column prop="code" label="code" />
        <el-table-column prop="type" label="type" width="150" />
        <el-table-column prop="creationTime" label="creationTime" width="200" />
        <el-table-column label="Operations" width="150">
          <template v-slot="scope">
            <div style="display: inline">
              <el-button
                @click.prevent="editRow(scope.$index)"
                type="text"
                size="small"
                >Edit</el-button
              >
              <el-button
                @click.prevent="deleteRow(scope.$index)"
                type="text"
                size="small"
                >Delete</el-button
              >
            </div>
          </template>
        </el-table-column>
      </el-table>
    </template>
    <template v-slot:footer>
      <el-pagination
        v-model:currentPage="currentPage"
        v-model:page-size="pageSize"
        :page-sizes="[10, 20, 50, 100]"
        :small="small"
        :total="pageTotal"
        layout="sizes, prev, pager, next, jumper, total"
        @current-change="pageChange"
        @size-change="pageChange"
      />
    </template>
  </main-template>
</template>

<script>
import MainTemplate from "@/components/main-template.vue";
import { request } from "@/utils/request.js";

export default {
  components: {
    MainTemplate,
  },
  data() {
    return {
      tableData: [],
      currentPage: 1,
      pageSize: 10,
      pageTotal: 0,
      small: false,
      form: {
        name: "",
        type: "",
      },
      selectData: [],
    };
  },
  mounted() {
    request("/api/getViewsType", "get").then((res) => {
      this.selectData = res.data;
    });

    this.currentPage = 1;
    this.pageSize = 10;
    this.pageTotal = 0;
    this.pageChange();
  },
  methods: {
    search() {
      this.currentPage = 1;
      this.pageSize = 10;
      this.pageTotal = 0;
      this.pageChange();
    },
    pageChange() {
      this.tableData = [];
      request("/api/searchPageCaxViews", "post", {
        pageSize: this.pageSize,
        currentPage: this.currentPage,
        name: this.form.name,
        type: this.form.type,
      }).then((result) => {
        if (result && result.code == 0 && result.data && result.data.rows) {
          this.tableData = result.data.rows;
          this.pageTotal = result.data.total;
        }
      });
    },
    addRow() {
      this.$router.push({
        name: "CaxViewsDetailPage",
      });
    },
    editRow(index) {
      this.$router.push({
        name: "CaxViewsDetailPage",
        query: {
          id: this.tableData[index].id,
        },
      });
    },
    deleteRow(index) {
      request("/api/removeCaxView", "post", {
        id: this.tableData[index].id,
      }).then(() => {
        this.$message({
          showClose: true,
          type: "success",
          message: "delete success",
        });
        this.pageChange();
      });
    },
  },
};
</script>
