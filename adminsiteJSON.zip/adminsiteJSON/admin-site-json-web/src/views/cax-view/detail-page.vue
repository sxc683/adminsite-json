<template>
  <main-template>
    <template v-slot:header>Cax Routes</template>
    <template v-slot:main>
      <el-form label-width="120px" label-position="top" :model="formData">
        <el-row>
          <el-col :span="11">
            <el-form-item label="Name">
              <el-input v-model="formData.name" />
            </el-form-item>
          </el-col>
          <el-col :span="1"></el-col>
          <el-col :span="11">
            <el-form-item label="Code">
              <el-input v-model="formData.code" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="11">
            <el-form-item label="Type">
              <el-select v-model="formData.type" clearable style="width: 100%">
                <el-option
                  v-for="(selectDataItem, indexItem) in selectData"
                  :key="indexItem"
                  :label="selectDataItem.label"
                  :value="selectDataItem.value"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="23">
            <el-form-item label="Config ">
              <el-input :rows="20" type="textarea" v-model="formData.config" />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </template>
    <template v-slot:footer>
      <el-button @click="backRouer">Cancle</el-button>
      <el-button type="primary" @click="AddOrUpdata">Save</el-button>
    </template>
  </main-template>
</template>

<script>
import MainTemplate from "@/components/main-template.vue";
import { request } from "@/utils/request.js";

export default {
  components: {
    MainTemplate,
  },
  data() {
    return {
      formData: {
        id: "",
        name: "",
        code: "",
        type: "",
        config: "",
      },
      otherData: {},
      selectData: [],
    };
  },
  mounted() {
    request("/api/getViewsType", "get").then((res) => {
      this.selectData = res.data;
    });

    if (this.$route.query.id) {
      request("/api/findCaxViewByID", "get", {
        id: this.$route.query.id,
      }).then((result) => {
        if (result && result.code == 0 && result.data) {
          this.formData.id = result.data.id;
          this.formData.name = result.data.name;
          this.formData.code = result.data.code;
          this.formData.type = result.data.type;
          this.formData.config = result.data.config;
          this.otherData = result.data;
        }
      });
    } else {
      this.formData.id = "";
      this.formData.name = "";
      this.formData.code = "";
      this.formData.type = "";
      this.formData.config = "";
    }
  },
  methods: {
    backRouer() {
      this.$router.push({
        name: "CaxViewsListPage",
      });
    },
    AddOrUpdata() {
      const postData = Object.assign(
        JSON.parse(JSON.stringify(this.otherData)),
        JSON.parse(JSON.stringify(this.formData))
      );
      if (this.$route.query.id) {
        request("/api/updataCaxView", "post", postData).then(() => {
          this.$message({
            showClose: true,
            type: "success",
            message: "change success",
          });
        });
      } else {
        request("/api/addCaxView", "post", postData).then(() => {
          this.$message({
            showClose: true,
            type: "success",
            message: "change success",
          });
        });
      }
    },
  },
};
</script>
