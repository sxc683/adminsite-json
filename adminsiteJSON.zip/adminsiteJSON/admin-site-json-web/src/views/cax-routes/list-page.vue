<template>
  <main-template>
    <template v-slot:header
      ><span>Routes</span>
      <el-button @click.prevent="addRow" style="float: right"
        >Add</el-button
      ></template
    >
    <template v-slot:search>
      <el-form :inline="true" :model="form" class="demo-form-inline">
        <el-form-item label="name">
          <el-input v-model="form.name" clearable></el-input>
        </el-form-item>
        <el-form-item label="type">
          <el-select v-model="form.type" clearable>
            <el-option
              v-for="(selectDataItem, indexItem) in selectData"
              :key="indexItem"
              :label="selectDataItem.label"
              :value="selectDataItem.value"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="pageChange">Query</el-button>
        </el-form-item>
      </el-form>
    </template>
    <template v-slot:main>
      <el-table
        :data="tableData"
        style="width: 100%"
        row-key="id"
        :tree-props="{ children: 'children', hasChildren: 'hasChildren' }"
        :default-expand-all="false"
      >
        <el-table-column prop="id" label="id" width="450" />
        <el-table-column prop="name" label="name" width="150" />
        <el-table-column prop="index" label="index" width="150" />
        <el-table-column prop="path" label="path" width="150" />
        <el-table-column prop="permission" label="permission" />
        <el-table-column label="Operations" width="150">
          <template v-slot="scope">
            <div style="display: inline">
              <el-button
                @click.prevent="editRow(scope.$index, scope)"
                type="text"
                size="small"
                >Edit</el-button
              >
              <el-button
                @click.prevent="deleteRow(scope.$index, scope)"
                v-show="scope.row.parentId"
                type="text"
                size="small"
                >Delete</el-button
              >
            </div>
          </template>
        </el-table-column>
      </el-table>
    </template>
  </main-template>
</template>

<script>
import MainTemplate from "@/components/main-template.vue";
import { request } from "@/utils/request.js";

export default {
  components: {
    MainTemplate,
  },
  data() {
    return {
      tableData: [],
      small: false,
      form: {
        name: "",
        type: "",
      },
      selectData: [],
    };
  },
  mounted() {
    request("/api/getRoutesType", "get").then((res) => {
      this.selectData = res.data;
    });

    this.pageChange();
  },
  methods: {
    pageChange() {
      this.tableData = [];
      request("/api/getAllCaxRoutesBytree", "post", {
        name: this.form.name,
        type: this.form.type,
      }).then((result) => {
        if (result && result.code == 0 && result.data) {
          this.tableData = result.data;
        }
      });
    },

    addRow() {
      this.$router.push({
        name: "CaxRoutesDetailPage",
      });
    },
    editRow(index, row) {
      this.$router.push({
        name: "CaxRoutesDetailPage",
        query: {
          id: row.row.id,
        },
      });
    },
    deleteRow(index, row) {
      request("/api/removeCaxRoute", "post", {
        id: row.row.id,
      }).then(() => {
        this.$message({
          showClose: true,
          type: "success",
          message: "delete success",
        });
        this.pageChange();
      });
    },
  },
};
</script>
