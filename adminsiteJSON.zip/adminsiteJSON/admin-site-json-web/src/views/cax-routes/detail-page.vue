<template>
  <main-template>
    <template v-slot:header>Cax Routes</template>
    <template v-slot:main>
      <el-form label-width="120px" label-position="top" :model="formData">
        <el-row>
          <el-col :span="11">
            <el-form-item label="type">
              <el-select v-model="formData.type" clearable style="width: 100%">
                <el-option
                  v-for="(selectDataItem, indexItem) in selectData"
                  :key="indexItem"
                  :label="selectDataItem.label"
                  :value="selectDataItem.value"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="1"></el-col>
          <el-col :span="11">
            <el-form-item label="icon">
              <el-input v-model="formData.icon" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="11">
            <el-form-item label="">
              <el-checkbox v-model="formData.isFrame">isFrame</el-checkbox>
            </el-form-item>
          </el-col>
          <el-col :span="1"></el-col>
          <el-col :span="11">
            <el-form-item label="">
              <el-checkbox v-model="formData.isHide">isHide</el-checkbox>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row>
          <el-col :span="11">
            <el-form-item label="name">
              <el-input v-model="formData.name" />
            </el-form-item>
          </el-col>
          <el-col :span="1"></el-col>
          <el-col :span="11">
            <el-form-item label="permission">
              <el-input v-model="formData.permission" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="11">
            <el-form-item label="parentId">
              <el-select
                v-model="formData.parentId"
                clearable
                style="width: 100%"
              >
                <el-option
                  v-for="(selectDataItem, indexItem) in routerData"
                  :key="indexItem"
                  :label="selectDataItem.name"
                  :value="selectDataItem.id"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="1"></el-col>
          <el-col :span="11">
            <el-form-item label="index">
              <el-input v-model="formData.index" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="11">
            <el-form-item label="path">
              <el-input v-model="formData.path" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="11">
            <el-form-item label="component">
              <el-input v-model="formData.component" />
            </el-form-item>
          </el-col>
          <el-col :span="1"></el-col>
          <el-col :span="11">
            <el-form-item label="viewId">
              <el-select
                v-model="formData.viewId"
                clearable
                style="width: 100%"
              >
                <el-option
                  v-for="(selectDataItem, indexItem) in viewData"
                  :key="indexItem"
                  :label="selectDataItem.name"
                  :value="selectDataItem.id"
                ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </template>
    <template v-slot:footer>
      <el-button @click="backRouer">Cancle</el-button>
      <el-button type="primary" @click="AddOrUpdata">Save</el-button>
    </template>
  </main-template>
</template>

<script>
import MainTemplate from "@/components/main-template.vue";
import { request } from "@/utils/request.js";

export default {
  components: {
    MainTemplate,
  },
  data() {
    return {
      formData: {
        id: "",
        type: "",
        icon: "",
        isFrame: "",
        isHide: "",
        name: "",
        permission: "",
        parentId: "",
        index: "",
        path: "",
        component: "",
        viewId: "",
      },
      otherData: {},
      selectData: [],
      viewData: [],
      routerData: [],
    };
  },
  mounted() {
    request("/api/getRoutesType", "get").then((res) => {
      this.selectData = res.data;
    });
    request("/api/getAllCaxViews", "get").then((res) => {
      this.viewData = res.data;
    });
    request("/api/getAllCaxRoutesByList", "post").then((res) => {
      this.routerData = res.data;
    });
    if (this.$route.query.id) {
      request("/api/findCaxRouteByID", "get", {
        id: this.$route.query.id,
      }).then((result) => {
        if (result && result.code == 0 && result.data) {
          this.formData.id = result.data.id;
          this.formData.type = result.data.type;
          this.formData.icon = result.data.icon;
          this.formData.isFrame = result.data.isFrame;
          this.formData.isHide = result.data.isHide;
          this.formData.name = result.data.name;
          this.formData.permission = result.data.permission;
          this.formData.parentId = result.data.parentId;
          this.formData.index = result.data.index;
          this.formData.path = result.data.path;
          this.formData.component = result.data.component;
          this.formData.viewId = result.data.viewId;
          this.otherData = result.data;
        }
      });
    } else {
      this.formData.id = "";
      this.formData.type = "";
      this.formData.icon = "";
      this.formData.isFrame = "";
      this.formData.isHide = "";
      this.formData.name = "";
      this.formData.permission = "";
      this.formData.parentId = "";
      this.formData.index = "";
      this.formData.path = "";
    }
  },
  methods: {
    backRouer() {
      this.$router.push({
        name: "CaxRoutesListPage",
      });
    },
    AddOrUpdata() {
      const postData = Object.assign(
        JSON.parse(JSON.stringify(this.otherData)),
        JSON.parse(JSON.stringify(this.formData))
      );
      if (this.$route.query.id) {
        request("/api/updataCaxRoute", "post", postData).then(() => {
          this.$message({
            showClose: true,
            type: "success",
            message: "change success",
          });
        });
      } else {
        request("/api/addCaxRoute", "post", postData).then(() => {
          this.$message({
            showClose: true,
            type: "success",
            message: "change success",
          });
        });
      }
    },
  },
};
</script>
