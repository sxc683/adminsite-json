<template>
  <div class="layout">
    <div class="header" v-if="$slots.header">
      <slot name="header"> </slot>
    </div>
    <div v-if="$slots.search" class="search">
      <slot name="search"></slot>
    </div>
    <div v-if="$slots.main" class="main">
      <slot name="main"></slot>
    </div>
    <div v-if="$slots.footer" class="footer">
      <slot name="footer"></slot>
    </div>
  </div>
</template>

<script>
export default {
  name: "MainTemplate",
};
</script>

<style lang="scss" scoped>
.layout {
  height: 100%;
  width: 100%;
  display: flex;
  flex-direction: column;
}

.header {
  height: 60px;
  line-height: 60px;
}

.main {
  flex: 1;
}

.search {
  height: auto;
}

.footer {
  height: 40px;
}
</style>
