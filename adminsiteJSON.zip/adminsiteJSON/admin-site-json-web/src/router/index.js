import { createRouter, createWebHistory } from "vue-router";
import Layout from "@/layout";

const routes = [
  {
    path: "/",
    component: Layout,
    redirect: "/main",
    children: [
      {
        path: "main",
        component: () => import("@/views/main/index"),
        name: "Main",
      },
    ],
  },
  {
    path: "/cax-routes/list-page",
    component: Layout,
    redirect: "/cax-routes/list-page",
    children: [
      {
        path: "cax-routes/list-page",
        component: () => import("@/views/cax-routes/list-page"),
        name: "CaxRoutesListPage",
      },
    ],
  },
  {
    path: "/cax-routes/detail-page",
    component: Layout,
    redirect: "/cax-routes/detail-page",
    children: [
      {
        path: "cax-routes/detail-page",
        component: () => import("@/views/cax-routes/detail-page"),
        name: "CaxRoutesDetailPage",
      },
    ],
  },

  {
    path: "/cax-view/list-page",
    component: Layout,
    redirect: "/cax-view/list-page",
    children: [
      {
        path: "cax-view/list-page",
        component: () => import("@/views/cax-view/list-page"),
        name: "CaxViewsListPage",
      },
    ],
  },
  {
    path: "/cax-view/detail-page",
    component: Layout,
    redirect: "/cax-view/detail-page",
    children: [
      {
        path: "cax-view/detail-page",
        component: () => import("@/views/cax-view/detail-page"),
        name: "CaxViewsDetailPage",
      },
    ],
  },
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

export default router;
